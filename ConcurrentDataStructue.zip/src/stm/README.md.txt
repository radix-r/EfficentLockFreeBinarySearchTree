In order to run:

1. java -jar deuceAgent.jar STMBST.jar STMBST_output.jar
2. java -jar STMBST_output.jar


